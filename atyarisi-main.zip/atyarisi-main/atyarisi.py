import random
import time

def at_yarisi():
    print("AT YARIŞI OYUNUNA HOŞGELDİNİZ!")
    print("-----------------------------")
    
    at_sayisi = 5
    atlar = []
    for i in range(at_sayisi):
        atlar.append({"numara": i+1, "konum": 0, "hiz": random.uniform(0.5, 1.2)})
    
    bitirenler = []
    
    print("Yarış başlıyor!\n")
    
    def pisti_ciz():
        print("\n" + "="*60)
        for at in atlar:
            durum = f"At {at['numara']}: [" + " " * int(at['konum']) + "🐎" + " " * (50 - int(at['konum'])) + "]"
            if at['numara'] in bitirenler:
                durum += f" → {bitirenler.index(at['numara'])+1}. oldu!"
            print(durum)
        print("="*60 + "\n")
    
    input("Başlamak için ENTER tuşuna basın...")
    
    baslangic_zamani = time.time()
    
    while len(bitirenler) < at_sayisi:
        for at in atlar:
            if at['numara'] not in bitirenler:
                at['konum'] += at['hiz'] * random.uniform(0.8, 1.2)
                
                if at['konum'] >= 50:
                    bitirenler.append(at['numara'])
                    at['konum'] = 50
                    at['bitis_zamani'] = time.time() - baslangic_zamani
        
        pisti_ciz()
        time.sleep(0.5)
    
    print("\nYARIŞ SONUÇLARI:")
    print("---------------")
    for sira, at_no in enumerate(bitirenler):
        for at in atlar:
            if at['numara'] == at_no:
                print(f"{sira+1}. At {at_no} → {at['bitis_zamani']:.2f} saniye")
                break
    
    tekrar = input("\nTekrar oynamak ister misiniz? (e/h): ").lower()
    if tekrar == 'e':
        print("\n"*3)
        at_yarisi()
    else:
        print("Oyun bitti. İyi günler!")

at_yarisi()
